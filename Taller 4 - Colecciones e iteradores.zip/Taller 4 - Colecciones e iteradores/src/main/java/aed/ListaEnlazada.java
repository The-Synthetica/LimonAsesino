package aed;

import java.util.*;

public class ListaEnlazada<T> implements Secuencia<T> {
    // Completar atributos privados

    private Nodo firstNode;
    private Nodo lastNode;
    private int longitud;

    private class Nodo {
        // Completar
        private Nodo back;
        private T value;
        private Nodo next;

        public Nodo( Nodo back, T valor, Nodo next){
            this.back= back;
            this.value= valor;
            this.next = next;
        }

        public Nodo( Nodo N ){
            this.back= new Nodo(N.WhoBack());
            this.next= new Nodo(N.WhoNext());
            this.value= N.Valor();
        }

        // Cambios de valores

        public void ValueTo( T valor ){
            this.value= valor;
        }

        public void NextTo( Nodo N ){
            this.next= N;
        }

        public void BackTo( Nodo N ){
            this.back= N;
        }

        // Retornos de valores
        public Nodo WhoNext(){
            return this.next;
        }
        public Nodo WhoBack(){
            return this.back;
        }

        public T Valor(){
            return this.value;
        }
    }

    public ListaEnlazada() {
//        throw new UnsupportedOperationException("No implementada aun");
    this.firstNode= null;
    this.lastNode= null;
    this.longitud= 0;
    }

    public int longitud() {
        return this.longitud;
    }

    //Mio <3

    private Nodo firstNode() {
        return this.firstNode;
    }

    private Nodo lastNode() {
        return this.lastNode;
    }

    //

    public void agregarAdelante(T elem) {
        Nodo N = new Nodo(null, elem, this.firstNode);
        this.longitud +=1;
        
        if(this.firstNode != null)
            this.firstNode.BackTo(N);
        this.firstNode= N;

        if(longitud == 1){
            this.lastNode= N;
        }
    }

    public void agregarAtras(T elem) {
        Nodo N = new Nodo(this.lastNode, elem, null);

        this.longitud +=1;
        
        if(this.lastNode != null)
            this.lastNode.NextTo(N);
        this.lastNode= N;

        if(longitud == 1){
            this.firstNode= N;
        }
    }

    public T obtener(int i) {

        Nodo N = this.firstNode;
        for(int j=0; j<i; j++){
            N = N.WhoNext();
        }
        return N.Valor();
    }

    public void eliminar(int i) {
        Nodo N = this.firstNode;

        for(int j=0; j<i; j++){
            N = N.WhoNext();
        }

        Nodo Back = N.WhoBack();
        Nodo Next = N.WhoNext();

        if( Next == null && Back == null){ 
            this.firstNode=null;
            this.lastNode=null;
            this.longitud--;
            return;
        }

        
        if( Next == null ){ 
            Back.NextTo(null);
            this.lastNode= Back;
            this.longitud--;
            return;
        }
        
        if( Back == null){ 
            Next.BackTo(null);
            this.firstNode= Next;
            this.longitud--;
            return;
        }
        
        Back.NextTo(Next);
        Next.BackTo(Back);
        this.longitud-=1;
    }

    public void modificarPosicion(int indice, T elem) {
        Nodo N = this.firstNode;

        for(int j=0; j<indice; j++){
            N = N.WhoNext();
        }

        N.ValueTo(elem);
    }

    public ListaEnlazada<T> copiar() {
        ListaEnlazada <T> newList = new ListaEnlazada<>();

        Nodo N = this.firstNode;

        for(int j=0; j< this.longitud; j++){
            //Creo que no se produce aliasing pero por las dudas \ (o.o) /;
            newList.agregarAtras( N.Valor() );
            N= N.WhoNext();
        }

        return newList;
    }

    public ListaEnlazada(ListaEnlazada<T> lista) {
        ListaEnlazada <T> newList = lista.copiar();

        this.firstNode = newList.firstNode();
        this.lastNode = newList.lastNode();
        this.longitud = newList.longitud();
    }
    
    @Override
    public String toString() {
        String res = "[";

        Nodo N = this.firstNode;

        for(int j=0; j< this.longitud; j++){
            //Creo que no se produce aliasing pero por las dudas \ (o.o) /;
            res += (N.Valor()).toString();
            if(j!=longitud-1)
                res+=", ";
            N= N.WhoNext();
        }
        
        res += "]";
        return res;
    }

    private class ListaIterador implements Iterador<T> {
    	// Completar atributos privados

        private Nodo dedito= firstNode;

        public boolean haySiguiente() {
            return dedito!= null;
        }
        
        public boolean hayAnterior() {
            return dedito.WhoBack()!= null;
        }

        public T siguiente() {
            T valor = dedito.Valor();
            dedito= dedito.WhoNext();
            return valor;
        }
        

        public T anterior() {
            T valor = dedito.Valor();
            dedito= dedito.WhoBack();
            return dedito.Valor();
        }
    }

    public Iterador<T> iterador() {
        return new ListaIterador() ;
    }

}

package aed;

import java.util.*;

// Todos los tipos de datos "Comparables" tienen el método compareTo()
// elem1.compareTo(elem2) devuelve un entero. Si es mayor a 0, entonces elem1 > elem2
public class ABB<T extends Comparable<T>> implements Conjunto<T> {
    // Agregar atributos privados del Conjunto

    private Nodo root;
    private int cont;

    private class Nodo {
        // Agregar atributos privados del Nodo

        // Completar
        private Nodo back;
        private T value;
        private Nodo right;
        private Nodo left;

        public Nodo( Nodo back, T valor, Nodo right, Nodo left){
            this.back= back;
            this.value= valor;
            this.right = right;
            this.left = left;
        }

        // Cambios de valores

        public void ValueTo( T valor ){
            this.value= valor;
        }

        public void RightTo( Nodo N ){
            this.right= N;

        }
        public void LeftTo( Nodo N ){
            this.left= N;
        }

        public void BackTo( Nodo N ){
            this.back= N;
        }

        // Retornos de valores
        public Nodo WhoRight(){
            return this.right;
        }

        public Nodo WhoLeft(){
            return this.left;
        }

        public Nodo WhoBack(){
            return this.back;
        }

        public T Valor(){
            return this.value;
        }
        // Crear Constructor del nodo
    }

    public ABB() {
        this.root = null;
        this.cont = 0;
    }

    public int cardinal() {
        return this.cont;
    }

    public T minimo(){
        Nodo aux = root;

        while(aux.WhoLeft()!=null){
            aux = aux.WhoLeft();
        }
        
        return aux.Valor();
    }

    public T maximo(){
        Nodo aux = root;

        while(aux.WhoRight()!=null){
            aux = aux.WhoRight();
        }
        
        return aux.Valor();
    }

    public void insertar(T elem){

        if(this.root == null){
            this.root = new Nodo(null, elem, null, null);
            this.cont++;
        }
        else
            handleInsert(this.root, elem);

    }
    
    // me harte agrego recursion
    private void handleInsert( Nodo N, T elem){

        if(N==null || elem.compareTo( N.Valor() ) == 0)
            return;

            
        if(elem.compareTo( N.Valor() ) < 0){
            //el elemento es mas chico
            if(N.WhoLeft() == null){
                N.LeftTo( new Nodo(N, elem, null, null) );
                this.cont++;
            }
            
            else
                handleInsert(N.WhoLeft(), elem);
        }

        else{
            //el elemento es mas grande
            if(N.WhoRight() == null){
                N.RightTo( new Nodo(N, elem, null, null) );
                this.cont++;
            }
            
            else
                handleInsert(N.WhoRight(), elem);
        }
    }

    public boolean pertenece(T elem){
        return handleIn(this.root, elem);
    }

    // me harte agrego recursion
    private boolean handleIn( Nodo N, T elem){
        if( N == null )
            return false;
        
        return (N.Valor() == elem ) || ( handleIn(N.WhoRight(), elem)) || (handleIn(N.WhoLeft(), elem));
    }

    public void eliminar(T elem){
        throw new UnsupportedOperationException("No implementada aun");
    }

    public String toString(){
        throw new UnsupportedOperationException("No implementada aun");
    }

    private class ABB_Iterador implements Iterador<T> {
        private Nodo _actual;

        public boolean haySiguiente() {            
            throw new UnsupportedOperationException("No implementada aun");
        }
    
        public T siguiente() {
            throw new UnsupportedOperationException("No implementada aun");
        }
    }

    public Iterador<T> iterador() {
        return new ABB_Iterador();
    }

}
